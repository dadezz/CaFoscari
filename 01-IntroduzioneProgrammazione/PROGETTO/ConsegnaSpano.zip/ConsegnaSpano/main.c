// 898103 897835
/**
 * @file snake
 * @authors Gabriele Cusano (897835), Davide Zambon (898103)
 * @date 02 feb 2023
 * @mainpage main.c
 * @section Introduzione
 *
 * Implementazione di un gioco il cui scopo è risolvere un labirinto trovandone l’uscita. 
 * sono previste 2 modalità:
 * (1) Modalità interattiva : L’utente che si approccia al gioco ha il compito di risolvere egli
 * stesso il labirinto, muovendosi al suo interno e cercando di ottenere il punteggio migliore
 * (2) Modalità AI (intelligenza artificiale) : il programma stesso ha il compito di trovare un
 * percorso valido che risolva il labirinto e che possibilmente sia il percorso migliore,
 * ovvero quello che restituisce il punteggio finale più elevato.
 * 
 * Il programma inizia con la scelta della modalità. L’utente può decidere se utilizzare una mappa 
 * predefinita oppure una personalizzata.
 * 
 * Il punteggio si calcola come 1000 - #passi_eseguiti + 10 * #bonus_raccolti
 * 
 * @section Struttura
 * I tipi di maggior rilevanza sono le struct del campo (board_t) e quella che gestisce gli array (vector_t).
 * La prima ha come campi due variabili di tipo size_t che rappresentano rispettivamente il numero di
 * righe e di colonne e un vettore di tipo char che memorizza la mappa. La seconda ha come campi
 * un vettore di int, la variabile size che rappresenta la lunghezza del vettore stesso e
 * la variabile capacity che contiene la lunghezza massima del vettore.
 * @subsection INTERATTIVA
 * Il giocatore comanda il personaggio digitando in input una delle
 * quattro direzioni proposte per muoversi : Nord, Sud, Est, Ovest. 
 * nello specifico, in input: W per Nord, S per Sud, A per Est, D per Ovest). 
 * A ogni mossa, viene, ne viene controllata la validità (celle libere, entro i bordi etc.) 
 * In caso di mossa non valida, il conteggio dei passi aumenta lo stesso, ma senza effetti nello spostamento.
 * Sono presenti celle speciali che modificano il flow del gioco, permettendo di attraversare muri, 
 * allungare e accorciare lo snake. La mappa è un vettore di caratteri monodimensionale, la
 * posizione della singola cella è rappresentata da un numero, che è l’indice dell’array. Lo
 * Snake viene rappresentato attraverso la lista delle posizioni che occupa all’interno della mappa.
 * Riteniamo che la parte più complicata da sviluppare sia stata il movimento Lo snake ha tipo vector_t
 * per semplicità di accesso tramite indice. quando si allunga o si accorcia, viene modificato il campo size.
 * Il movimento è stato fatto pensando agli effetti che deve avere graficamente all’interno del gioco. 
 * Abbiamo usato un vector_t ausiliario per memorizzare lo stato precedente dello snake, perché poi fosse facile 
 * aggiungere, togliere e modificare alementi. 
 * Quando viene incontrato un bonus ('$'), lo snake si allunga.
 * Quando viene incontrato un imprevisto ('!'), lo snake si dimezza.
 * @subsection IA
 * Il computer, nel limite massimo di un minuto, deve trovare il percorso migliore (o quello che
 * più gli si avvicina). Sono stati implementati 2 algoritmi:
 * (1) “numeretti”: A partire dalla cella iniziale, a cui si dà
 * valore 1, si assegna valore 2 alle celle vuote adiacenti, e così via, ogni volta si incrementa di uno.
 * Così facendo, si arriva alla fine col numero di passi minore in assoluto, ma non vengono
 * prese in considerazione le celle speciali. 
 * (2) funzione ricorsiva: ad ogni passo esplora tutti i possibili percorsi nelle quattro direzioni,
 * calcolando per ognuno il punteggio e restituendo il migliore. 
 * 
 * Il problema dell'efficienza computativa della (2) viene mitigato in 2 modi:
 * (1) riduzione: La mappa viene modificata tramite euristiche 
 * (quali per esempio riempire di muri i vicoli ciechi opassaggi di larghezza maggiore di 1) 
 * che intaccano solo il funzionamento del trapano e solo in piccola parte, dando quindi un enorme vantaggio 
 * a fronte di una penalizzazione statisticamente bassa sul punteggio finale. 
 * (2) Troncamento: Al raggiungimento del minuto, viene restituito il percorso migliore finora trovato. 
*/
#ifndef  _HEADERS_
#define  _HEADERS_
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include"types.h"
#endif // _HEADERS_

#ifndef _FUNCTIONS_
#define _FUNCTIONS_
#include "func.h"
#endif //_FUNCTIONS_


int main(int argc, char* argv[]){

    if (argc > 1){
        if(!strcmp(argv[1],"--challenge")){
            board_t *new_map;
            new_map = malloc(sizeof(board_t));
            new_map = map_input_creation(new_map);
            mod_ai(new_map);
        }
    }
    else {
        char sample_map[] =  {'#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#',
                            'o',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ',' ',' ','T','#',' ',' ','#',
                            '#',' ',' ','#',' ',' ','#',' ',' ','#',' ','!','#',' ',' ','#',' ',' ','#',
                            '#',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ','#',' ','$','#',' ',' ','#',
                            '#',' ','$','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ','$','#',' ',' ','#',
                            '#',' ','!','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ',' ',' ',' ',' ','#',
                            '#',' ','$','#',' ','$','$','$','$','#',' ',' ','#',' ',' ','#',' ',' ','#',
                            '#',' ','$','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ',' ','#','$',' ','#',
                            '#',' ','$','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ',' ','#','$',' ','#',
                            '#',' ','T','#',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ','#','$',' ','#',
                            '#',' ',' ','#',' ',' ','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ',' ','_',
                            '#',' ',' ','#',' ',' ','#',' ',' ',' ',' ',' ','#',' ',' ','#',' ','!','#',
                            '#',' ',' ',' ','!',' ','#',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ','#',
                            '#',' ',' ',' ',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ','#',' ',' ','#',
                            '#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#','#'};

        board_t *default_map;
        default_map = malloc(sizeof(board_t));
        default_map->row = 15;
        default_map->col = 19;
        default_map->map = malloc(default_map->row * default_map->col);
        for (int i=0; i<default_map->row * default_map->col; i++){
            default_map->map[i] = sample_map[i];
        }

        int choice_mod = ask_mod(); // Modalità interattiva (1) o IA (0)
        int choice_default = ask_default(); //vuole inserire mappa in input: si (0), no (1)
        if (choice_default == 1) {
            /**
             * ha scelto di usare la mappa di default: il prossimo switch-case è relativo a IA o interactive
            */
            switch (choice_mod){
                case 1: 
                    mod_interactive(default_map);
                    break;
                case 2:
                    mod_ai(default_map);
                    break;
            }
        }
        else {
            /**
             * nel caso in cui avesse invece scelto di usarne una sua
            */
            board_t *new_map;
            new_map = malloc(sizeof(board_t));
            new_map = map_input_creation(new_map);
            
            switch (choice_mod){
                case 1: {
                    mod_interactive(new_map);
                    break;
                }
                case 2: {
                    mod_ai(new_map);
                    break;
                }
            }
            free(new_map);
        }
        free(default_map->map);
        free(default_map);
    }

    return 0;
}