var searchData=
[
  ['input_5fchar_26',['input_char',['../interactive_8c.html#aebfdcbc8c39b7eecc8cbc28d08ff872f',1,'interactive.c']]],
  ['input_5feffect_27',['input_effect',['../interactive_8c.html#ae80af80a8807aa5a3da5e6450f19051c',1,'interactive.c']]],
  ['interactive_2ec_28',['interactive.c',['../interactive_8c.html',1,'']]],
  ['is_5fin_5fsnake_29',['is_in_snake',['../interactive_8c.html#acfcc5dce7277d30ef14ceb86d5ff53ba',1,'interactive.c']]],
  ['isola_5foggetti_30',['isola_oggetti',['../riduzione_8c.html#a51635fae68ff3b7973c41dd778449181',1,'riduzione.c']]]
];
