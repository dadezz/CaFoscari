var searchData=
[
  ['v_5fclone_57',['v_clone',['../dvector__t_8h.html#a239190b7d04b73b02019a6fe26f4bc7f',1,'dvector.c']]],
  ['v_5fcreate_58',['v_create',['../dvector__t_8h.html#aff078316d1196f8ddf865c7eaec2c8d5',1,'dvector.c']]],
  ['v_5ffree_59',['v_free',['../dvector__t_8h.html#aa5dc997ba4e134398cccf3fc13bcf6a5',1,'dvector.c']]],
  ['v_5fget_60',['v_get',['../dvector__t_8h.html#acbbf4c68565b4b3cc274a2de51568ad7',1,'dvector.c']]],
  ['v_5fis_5fempty_61',['v_is_empty',['../dvector__t_8h.html#a57f80391ba3f265bd2cf19070001492a',1,'dvector.c']]],
  ['v_5fpop_5fback_62',['v_pop_back',['../dvector__t_8h.html#a82dd933175edf1cdcec7c4458e81dfae',1,'dvector.c']]],
  ['v_5fprint_63',['v_print',['../dvector__t_8h.html#a188cfa57b8eaea8160178e3e1cee5063',1,'dvector.c']]],
  ['v_5fpush_5fback_64',['v_push_back',['../dvector__t_8h.html#a591d8a59467cfe00aafd2e45f24dc104',1,'dvector.c']]],
  ['v_5fsize_65',['v_size',['../dvector__t_8h.html#ab91e1473e86b81a84767942dc7da43d8',1,'dvector.c']]],
  ['vector_66',['vector',['../structvector.html',1,'']]],
  ['vector_5ft_67',['vector_t',['../structvector__t.html',1,'']]],
  ['vicolo_5fcieco_68',['vicolo_cieco',['../riduzione_8c.html#aecb8fdd24cdba8317de2145c552d2f98',1,'riduzione.c']]]
];
