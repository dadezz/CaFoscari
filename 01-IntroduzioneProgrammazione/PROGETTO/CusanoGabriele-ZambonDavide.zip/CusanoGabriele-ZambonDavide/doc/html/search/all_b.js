var searchData=
[
  ['riduci_47',['riduci',['../riduzione_8c.html#afe4cf457ea2be3af892a74b71ebbc462',1,'riduzione.c']]],
  ['riduzione_48',['riduzione',['../func_8h.html#a398aea24ee5edcb8c59069bb478385a9',1,'riduzione(board_t map):&#160;riduzione.c'],['../riduzione_8c.html#a398aea24ee5edcb8c59069bb478385a9',1,'riduzione(board_t map):&#160;riduzione.c']]],
  ['riduzione_2ec_49',['riduzione.c',['../riduzione_8c.html',1,'']]],
  ['rimetti_5fspazi_50',['rimetti_spazi',['../riduzione_8c.html#ad3be4345b1db33502ea48faec6430b79',1,'riduzione.c']]]
];
