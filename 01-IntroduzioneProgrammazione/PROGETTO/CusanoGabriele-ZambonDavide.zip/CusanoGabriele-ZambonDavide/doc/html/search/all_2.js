var searchData=
[
  ['best_5fpercorso_10',['best_percorso',['../Aifunc_8c.html#a1967973ccb868d860db7fff420da55f9',1,'Aifunc.c']]],
  ['board_5ft_11',['board_t',['../structboard__t.html',1,'']]]
];
