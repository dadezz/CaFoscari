var searchData=
[
  ['_5fv_5fcheck_5fextend_80',['_v_check_extend',['../dvector__t_8h.html#a352ae8a47460c389223ca3dc4840eeb8',1,'dvector.c']]],
  ['_5fv_5fcheck_5findex_81',['_v_check_index',['../dvector__t_8h.html#adf8ddf95c86eeac11d9339abf1459256',1,'dvector.c']]],
  ['_5fv_5fcheck_5fnon_5fempty_82',['_v_check_non_empty',['../dvector__t_8h.html#af845300974eba87d519f7e9b565b31b4',1,'dvector.c']]],
  ['_5fv_5fcheck_5fshrink_83',['_v_check_shrink',['../dvector__t_8h.html#aede6d40d3866a806a9d03b53d2619d41',1,'dvector.c']]]
];
