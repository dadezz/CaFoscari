var indexSectionsWithContent =
{
  0: "_abcdefimnprstv",
  1: "bpv",
  2: "acdfirt",
  3: "_abcdefimnprsv",
  4: "s",
  5: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Strutture dati",
  2: "File",
  3: "Funzioni",
  4: "Ridefinizioni di tipo (typedef)",
  5: "Pagine"
};

