var searchData=
[
  ['adiacente_5fchiocciola_5fmuro_84',['adiacente_chiocciola_muro',['../riduzione_8c.html#ae3c06ef83ec744b2161304e08cda1c38',1,'riduzione.c']]],
  ['adiacente_5fchiocciola_5ftre_85',['adiacente_chiocciola_tre',['../riduzione_8c.html#a093779ec27f1cbf58904acd558897776',1,'riduzione.c']]],
  ['angolo_5flibero_86',['angolo_libero',['../riduzione_8c.html#a37fbcbec216d8f45553825c85ab9ef50',1,'riduzione.c']]],
  ['ask_5fdefault_87',['ask_default',['../common_8c.html#aa24959083f44478f43cb99e9dba1a398',1,'ask_default():&#160;common.c'],['../func_8h.html#aa24959083f44478f43cb99e9dba1a398',1,'ask_default():&#160;common.c']]],
  ['ask_5fmod_88',['ask_mod',['../common_8c.html#aedb8e5af76c91063912114fb48f20979',1,'ask_mod():&#160;common.c'],['../func_8h.html#aedb8e5af76c91063912114fb48f20979',1,'ask_mod():&#160;common.c']]]
];
