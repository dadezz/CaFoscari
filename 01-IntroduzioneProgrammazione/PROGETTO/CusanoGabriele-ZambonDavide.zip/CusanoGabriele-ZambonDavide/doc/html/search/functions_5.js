var searchData=
[
  ['elimina_5forfani_95',['elimina_orfani',['../riduzione_8c.html#a97c371fa66285e235afd5bd9cf4ccb49',1,'riduzione.c']]],
  ['elimina_5fpassi_96',['elimina_passi',['../Aifunc_8c.html#a106eca2452f080c23b0b774c1f1e97fa',1,'Aifunc.c']]],
  ['elimina_5ftre_5finutili_97',['elimina_tre_inutili',['../riduzione_8c.html#a919156af869504bedefe64a5ec8b852b',1,'riduzione.c']]],
  ['elimina_5fvicoli_5fciechi_98',['elimina_vicoli_ciechi',['../riduzione_8c.html#a5a04a505b431869b1822e68e38fce067',1,'riduzione.c']]],
  ['errore_99',['errore',['../common_8c.html#a8b1c470a7ef75a77843b5ac73d3b98e2',1,'errore():&#160;common.c'],['../func_8h.html#a8b1c470a7ef75a77843b5ac73d3b98e2',1,'errore():&#160;common.c']]]
];
