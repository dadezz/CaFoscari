var searchData=
[
  ['check_5fpos_90',['check_pos',['../interactive_8c.html#a633cc76d8a16ae035139d3c406a3ad77',1,'interactive.c']]],
  ['copia_5fmappa_91',['copia_mappa',['../common_8c.html#aba6723e66a44da69200eb1f7d0ff519c',1,'copia_mappa(board_t *map):&#160;common.c'],['../func_8h.html#aba6723e66a44da69200eb1f7d0ff519c',1,'copia_mappa(board_t *map):&#160;common.c']]],
  ['create_5fpos_92',['create_pos',['../interactive_8c.html#af4ceb1dc75bd6d1d4ba943934a68d4e6',1,'interactive.c']]]
];
