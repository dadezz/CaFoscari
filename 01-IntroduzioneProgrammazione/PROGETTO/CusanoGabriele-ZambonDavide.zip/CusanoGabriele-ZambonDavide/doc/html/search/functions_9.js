var searchData=
[
  ['not_5fin_114',['not_in',['../common_8c.html#aecf4fabd338098d2d32a36f9908015fa',1,'not_in(vector_t percorso, position_t pos, board_t map):&#160;common.c'],['../func_8h.html#aecf4fabd338098d2d32a36f9908015fa',1,'not_in(vector_t percorso, position_t pos, board_t map):&#160;common.c']]],
  ['numeretti_115',['numeretti',['../Aifunc_8c.html#ac8bdc66469646e3add577bc235c158d7',1,'Aifunc.c']]]
];
