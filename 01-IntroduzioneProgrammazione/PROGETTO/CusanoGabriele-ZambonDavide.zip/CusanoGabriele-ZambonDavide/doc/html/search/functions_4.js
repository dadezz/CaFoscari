var searchData=
[
  ['delete_5fel_93',['delete_el',['../interactive_8c.html#a6cff8ed49871567f9672e528ea0fea5a',1,'interactive.c']]],
  ['doppia_5ffila_94',['doppia_fila',['../riduzione_8c.html#a903f54885c7d12f7487ab7db68d2b968',1,'riduzione.c']]]
];
