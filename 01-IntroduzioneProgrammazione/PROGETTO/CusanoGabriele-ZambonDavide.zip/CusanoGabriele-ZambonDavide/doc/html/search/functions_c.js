var searchData=
[
  ['scambia_5fpunteggio_5fmax_123',['scambia_punteggio_max',['../Aifunc_8c.html#a96ae72d3de67561d96be28f5416a98de',1,'Aifunc.c']]],
  ['stampa_5fdirezioni_124',['stampa_direzioni',['../common_8c.html#a563c3efc1c5a39993e0fbdb33681ab81',1,'stampa_direzioni(vector_t p, board_t map):&#160;common.c'],['../func_8h.html#a563c3efc1c5a39993e0fbdb33681ab81',1,'stampa_direzioni(vector_t p, board_t map):&#160;common.c']]],
  ['stampa_5fpiu_125',['stampa_piu',['../common_8c.html#a27dc8b83bce1a7fe46c41af6c1aef083',1,'stampa_piu(board_t map, vector_t percorso):&#160;common.c'],['../func_8h.html#a27dc8b83bce1a7fe46c41af6c1aef083',1,'stampa_piu(board_t map, vector_t percorso):&#160;common.c']]]
];
