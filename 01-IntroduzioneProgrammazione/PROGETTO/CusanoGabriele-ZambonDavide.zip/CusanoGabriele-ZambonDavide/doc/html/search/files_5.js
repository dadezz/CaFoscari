var searchData=
[
  ['riduzione_2ec_78',['riduzione.c',['../riduzione_8c.html',1,'']]]
];
