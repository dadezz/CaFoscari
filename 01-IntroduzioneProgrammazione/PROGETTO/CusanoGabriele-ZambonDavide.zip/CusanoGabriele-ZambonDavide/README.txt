 GRUPPO = CusanoGabriele-ZambonDavide
 COMPONENTI = Cusano Gabriele (897835), Zambon Davide (898103)
